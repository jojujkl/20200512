from django.apps import AppConfig


class FormapiConfig(AppConfig):
    name = 'formapi'
